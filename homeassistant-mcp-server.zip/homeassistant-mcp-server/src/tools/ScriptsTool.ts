import { MCPTool } from 'mcp-framework';

export default class ScriptsTool extends MCPTool<{}> {
  name = 'get_scripts';
  description = 'Retrieve all scripts from Home Assistant';
  schema = {};

  async execute() {
    const res = await this.fetch('/api/scripts');
    return res;
  }
}
