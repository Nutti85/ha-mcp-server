import { MCPTool } from 'mcp-framework';

export default class ScenesTool extends MCPTool<{}> {
  name = 'get_scenes';
  description = 'Retrieve all scenes from Home Assistant';
  schema = {};

  async execute() {
    return await this.fetch('/api/scenes');
  }
}
