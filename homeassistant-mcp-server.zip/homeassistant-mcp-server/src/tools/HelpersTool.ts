import { MCPTool } from 'mcp-framework';

export default class HelpersTool extends MCPTool<{}> {
  name = 'get_helpers';
  description = 'Retrieve all helpers from Home Assistant';
  schema = {};

  async execute() {
    return await this.fetch('/api/helpers');
  }
}
