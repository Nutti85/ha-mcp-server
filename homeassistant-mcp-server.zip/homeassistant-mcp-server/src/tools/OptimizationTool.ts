import { MCPTool } from 'mcp-framework';
import { z } from 'zod';

interface OptimizeInput {
  type: 'automations' | 'scripts' | 'scenes' | 'helpers';
  items: any[];
}

export default class OptimizationTool extends MCPTool<OptimizeInput> {
  name = 'recommend_optimizations';
  description = 'Analyze items and recommend optimizations';
  schema = {
    type: { type: z.enum(['automations','scripts','scenes','helpers']), description: 'Which items to optimize' },
    items: { type: z.array(z.any()), description: 'Array of items from HA' }
  };

  async execute({ type, items }: OptimizeInput) {
    const recs: string[] = [];
    if (type === 'automations') {
      items.forEach(a => {
        if (!a.enabled) recs.push(`Automation "${a.alias}" is disabled—consider removing or enabling.`);
        if (a.trigger.length > 5) recs.push(`"${a.alias}" has ${a.trigger.length} triggers—simplify if possible.`);
      });
    }
    if (type === 'scripts') {
      items.forEach(s => {
        if (s.sequence.length > 10) recs.push(`Script "${s.id}" is long—consider splitting.`);
      });
    }
    if (type === 'scenes' && items.length > 20) {
      recs.push(`You have ${items.length} scenes—consider consolidating similar ones.`);
    }
    if (type === 'helpers') {
      items.forEach(h => {
        if (h.type === 'input_number' && h.min === 0 && h.max === 100) {
          recs.push(`Helper "${h.name}" uses a default range 0–100—ensure that fits your needs.`);
        }
      });
    }
    return { type, recommendations: recs };
  }
}
