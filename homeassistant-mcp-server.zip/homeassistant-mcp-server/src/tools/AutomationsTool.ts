import { MCPTool } from 'mcp-framework';

export default class AutomationsTool extends MCPTool<{}> {
  name = 'get_automations';
  description = 'Retrieve all automations from Home Assistant';
  schema = {}; // no inputs

  async execute() {
    const res = await this.fetch<{ id: string; alias: string; enabled: boolean; trigger: any[]; action: any[]}[]>('/api/automations');
    return res;
  }
}
