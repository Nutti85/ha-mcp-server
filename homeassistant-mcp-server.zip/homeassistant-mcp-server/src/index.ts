import 'dotenv/config';
import { MCPServer, APIKeyAuthProvider } from 'mcp-framework';
import HomeAssistantClient from './resources/HomeAssistantClient';

const port = parseInt(process.env.PORT || '8080', 10);

// Simple API‑Key auth
const authProvider = new APIKeyAuthProvider({
  keys: [process.env.API_KEY || ''],
  headerName: 'X-API-Key'
});

const server = new MCPServer({
  transport: {
    type: 'sse',
    options: {
      port,
      endpoint: '/sse',
      messageEndpoint: '/messages',
      headers: { 'Cache-Control': 'no-cache' },
      cors: {
        allowOrigin: '*',
        allowMethods: 'GET, POST, OPTIONS',
        allowHeaders: 'Content-Type, X-API-Key',
        exposeHeaders: 'Content-Type, X-API-Key',
        maxAge: '86400'
      },
      auth: {
        provider: authProvider,
        endpoints: { sse: true, messages: true }
      }
    }
  },
  resources: [new HomeAssistantClient()]
});

// Auto‑discovers any tools in src/tools
server.start().catch((err) => {
  console.error('Failed to start MCP server:', err);
  process.exit(1);
});
