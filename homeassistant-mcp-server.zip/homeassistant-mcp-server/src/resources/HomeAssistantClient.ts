import { MCPResource } from 'mcp-framework';
import axios, { AxiosInstance } from 'axios';

export default class HomeAssistantClient extends MCPResource {
  uri = 'resource://homeassistant';
  name = 'Home Assistant';
  description = 'Fetch automations, scripts, scenes, helpers from HA';
  mimeType = 'application/json';
  private client: AxiosInstance;

  constructor() {
    super();
    const baseUrl = process.env.HOME_ASSISTANT_URL;
    const token = process.env.HOME_ASSISTANT_TOKEN;
    if (!baseUrl || !token) {
      throw new Error('HOME_ASSISTANT_URL and HOME_ASSISTANT_TOKEN must be set');
    }
    this.client = axios.create({
      baseURL: baseUrl,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
  }

  async read() {
    const [automations, scripts, scenes, helpers] = await Promise.all([
      this.client.get('/api/automations').then((r) => r.data),
      this.client.get('/api/scripts').then((r) => r.data),
      this.client.get('/api/scenes').then((r) => r.data),
      this.client.get('/api/helpers').then((r) => r.data)
    ]);
    return [
      {
        uri: this.uri,
        mimeType: this.mimeType,
        text: JSON.stringify({ automations, scripts, scenes, helpers })
      }
    ];
  }
}
